module("luci.passwall.api", package.seeall)
appname = "passwall"
c_config = "passwall"
s_config = "passwall_server"
local com = require "luci.passwall.com"
nixio = require "nixio"
fs = require "nixio.fs"
sys = require "luci.sys"
uci = require "luci.model.uci".cursor()
util = require "luci.util"
datatypes = require "luci.cbi.datatypes"
jsonc = require "luci.jsonc"
i18n = require "luci.i18n"

curl_args = { "-skfL", "--connect-timeout 3", "--retry 3", "-H 'Accept: */*'" }
command_timeout = 300
OPENWRT_ARCH = nil
DISTRIB_ARCH = nil
OPENWRT_BOARD = nil

LOCK_PREFIX = "/var/lock/" .. c_config
LOG_FILE = "/tmp/log/" .. c_config .. ".log"
TMP_PATH = "/tmp/etc/" .. c_config
CACHE_PATH = TMP_PATH .. "_tmp"
S_TMP_PATH = "/tmp/etc/" .. s_config
TMP_IFACE_PATH = TMP_PATH .. "/iface"

function log(...)
	local result = os.date("%Y-%m-%d %H:%M:%S: ") .. table.concat({...}, " ")
	local f, err = io.open(LOG_FILE, "a")
	if f and err == nil then
		f:write(result .. "\n")
		f:close()
	end
end

function is_old_uci()
	return sys.call("grep -E 'require[ \t]*\"uci\"' /usr/lib/lua/luci/model/uci.lua >/dev/null 2>&1") == 0
end

function uci_del(config, section, option)
	if option then
		return uci:delete(config, section, option)
	else
		return uci:delete(config, section)
	end
end

function uci_get(config, section, option)
	if not section then
		return uci:get_all(config)
	elseif option then
		return uci:get(config, section, option) or nil
	else
		return uci:get_all(config, section)
	end
end

function uci_set(config, section, option, value)
	if type(value) == "number" then
		value = value .. ""
	end
	if #value > 0 then
		if option then
			if type(value) == "table" then
				return uci:set_list(config, section, option, value)
			else
				return uci:set(config, section, option, value)
			end
		else
			return uci:set(config, section, value)
		end
	else
		return uci_del(config, section, option)
	end
end

function uci_del_c(section, option)
	return uci_del(c_config, section, option)
end

function uci_foreach_c(stype, func)
	uci:foreach(c_config, stype, func)
end

function uci_get_c(section, option)
	return uci_get(c_config, section, option)
end

function uci_set_c(section, option, value)
	return uci_set(c_config, section, option, value)
end

function uci_save_c(commit, apply)
	return uci_save(uci, c_config, commit, apply)
end

function uci_del_s(section, option)
	return uci_del(s_config, section, option)
end

function uci_foreach_s(stype, func)
	uci:foreach(s_config, stype, func)
end

function uci_get_s(section, option)
	return uci_get(s_config, section, option)
end

function uci_set_s(section, option, value)
	return uci_set(s_config, section, option, value)
end

function uci_save_s(commit, apply)
	return uci_save(uci, s_config, commit, apply)
end

function uci_save(cursor, config, commit, apply)
	if not cursor then cursor = uci end
	if is_old_uci() then
		cursor:save(config)
		if commit then
			cursor:commit(config)
			if apply then
				sys.call("/etc/init.d/" .. config .. " reload > /dev/null 2>&1 &")
			end
		end
	else
		commit = true
		if commit then
			if apply then
				cursor:commit(config)
			else
				sh_uci_commit(config)
			end
		end
	end
end

function sh_uci_get(config, section, option)
	local _, val = exec_call(string.format("uci -q get %s.%s.%s", config, section, option))
	return val
end

function sh_uci_set(config, section, option, val, commit)
	exec_call(string.format("uci -q set %s.%s.%s=\"%s\"", config, section, option, val))
	if commit then sh_uci_commit(config) end
end

function sh_uci_del(config, section, option, commit)
	exec_call(string.format("uci -q delete %s.%s.%s", config, section, option))
	if commit then sh_uci_commit(config) end
end

function sh_uci_add_list(config, section, option, val, commit)
	exec_call(string.format("uci -q del_list %s.%s.%s=\"%s\"", config, section, option, val))
	exec_call(string.format("uci -q add_list %s.%s.%s=\"%s\"", config, section, option, val))
	if commit then sh_uci_commit(config) end
end

function sh_uci_commit(config)
	exec_call(string.format("uci -q commit %s", config))
end

function del_cache_var(key)
	sys.call(string.format('. /usr/share/passwall2/utils.sh ; del_cache_var "%s"', key))
end

function set_cache_var(key, val)
	sys.call(string.format('. /usr/share/passwall/utils.sh ; set_cache_var "%s" "%s"', key, val))
end

function get_cache_var(key)
	local val = sys.exec(string.format('. /usr/share/passwall/utils.sh ; echo -n $(get_cache_var "%s")', key))
	if val == "" then val = nil end
	return val
end

function get_new_port()
	local cmd_format = ". /usr/share/passwall/utils.sh ; echo -n $(get_new_port %s tcp,udp)"
	return tonumber(sys.exec(string.format(cmd_format, "auto")))
end

function exec_call(cmd)
	math.randomseed(os.time())
	local tag = "\x01__RC__" .. tostring(math.random(100000, 999999)) .. "\x01"
	local f = io.popen('(' .. cmd .. ') 2>&1; printf "\\n' .. tag .. '%d" "$?"')
	local out = f:read("*a") or ""
	f:close()
	local rc = out:match(tag .. "(%d+)%s*$")
	if not rc then
		return 255, trim(out)
	end
	out = out:gsub("\n?" .. tag .. "%d+%s*$", "")
	return tonumber(rc), trim(out)
end

function base64Decode(text)
	if type(text) ~= "string" then return "" end
	local encoded = text:gsub("%z", ""):gsub("%c", ""):gsub("_", "/"):gsub("-", "+"):gsub("=+$", "")
	if encoded == "" then return text end
	if not encoded:match("^[A-Za-z0-9+/]*$") then return text end
	local mod4 = #encoded % 4
	if mod4 == 1 then return text end
	local padded = encoded .. string.rep("=", (4 - mod4) % 4)
	local result = nixio.bin.b64decode(padded)
	if not result then return text end
	-- Verify that the normalized input is canonical Base64.
	local reencoded = nixio.bin.b64encode(result):gsub("=+$", "")
	if reencoded ~= encoded then return text end
	return (result:gsub("%z", ""))
end

function base64Encode(text)
	if not text then return nil end
	return nixio.bin.b64encode(text)
end

function UrlEncode(szText)
	if type(szText) ~= "string" then return "" end
	return szText:gsub("([^%w%-_%.%~])", function(c)
		return string.format("%%%02X", string.byte(c))
	end)
end

function UrlDecode(szText)
	if type(szText) ~= "string" then return "" end
	return szText and szText:gsub("%+", " "):gsub("%%(%x%x)", function(h)
		return string.char(tonumber(h, 16))
	end) or nil
end

-- 计算文件 MD5
function md5_file(path)
	if type(path) ~= "string" then return "" end
	local quoted = "'" .. path:gsub("'", "'\\''") .. "'"
	local out = sys.exec("md5sum " .. quoted)
	if not out then return "" end
	return out:sub(1, 32)
end

-- 计算字符串 MD5
function md5_string(str)
	if type(str) ~= "string" then return "" end
	local quoted = "'" .. str:gsub("'", "'\\''") .. "'"
	local out = sys.exec("printf '%s' " .. quoted .. " | md5sum")
	if not out then return "" end
	return out:sub(1, 32)
end

--提取URL中的域名和端口(no ip)
function get_domain_port_from_url(url)
	local scheme, domain, port = string.match(url, "^(https?)://([%w%.%-]+):?(%d*)")
	if not domain then
		scheme, domain, port = string.match(url, "^(https?)://(%b[])([^:/]*)/?")
	end
	if not domain then return nil, nil end
	if domain:sub(1, 1) == "[" then domain = domain:sub(2, -2) end
	port = port ~= "" and tonumber(port) or (scheme == "https" and 443 or 80)
	if datatypes.ipaddr(domain) or datatypes.ip6addr(domain) then return nil, nil end
	return domain, port
end

--解析域名
function domainToIPv4(domain, dns)
	local Dns = dns or "223.5.5.5"
	local IPs = luci.sys.exec('nslookup %s %s | awk \'/^Name:/{getline; if ($1 == "Address:") print $2}\'' % { domain, Dns })
	for IP in string.gmatch(IPs, "%S+") do
		if datatypes.ipaddr(IP) and not datatypes.ip6addr(IP) then return IP end
	end
	return nil
end

function curl_base(url, file, args)
	if not args then args = {} end
	if file then
		args[#args + 1] = "-o " .. file
	end
	local cmd = string.format('curl %s "%s"', table_join(args), url)
	return exec_call(cmd)
end

function curl_proxy(url, file, args)
	--使用代理
	local socks_server = get_cache_var("GLOBAL_SOCKS_server")
	if socks_server and socks_server ~= "" then
		if not args then args = {} end
		local tmp_args = clone(args)
		tmp_args[#tmp_args + 1] = "-x socks5h://" .. socks_server
		return curl_base(url, file, tmp_args)
	end
	return nil, nil
end

function curl_logic(url, file, args)
	local return_code, result = curl_proxy(url, file, args)
	if not return_code or return_code ~= 0 then
		return_code, result = curl_base(url, file, args)
	end
	return return_code, result
end

function curl_direct(url, file, args)
	--直连访问
	local chn_list = uci_get_c("@global[0]", "chn_list") or "direct"
	local Dns = (chn_list == "proxy") and "1.1.1.1" or "223.5.5.5"
	if not args then args = {} end
	local tmp_args = clone(args)
	local domain, port = get_domain_port_from_url(url)
	if domain then
		local ip = domainToIPv4(domain, Dns)
		if ip then
			tmp_args[#tmp_args + 1] = "--resolve " .. domain .. ":" .. port .. ":" .. ip
		end
	end
	return curl_base(url, file, tmp_args)
end

function curl_auto(url, file, args)
	local localhost_proxy = uci_get_c("@global[0]", "localhost_proxy") or "1"
	if localhost_proxy == "1" then
		return curl_base(url, file, args) -- 当路由器本机开启代理时，采用passwall规则进行访问
	else
		local return_code, result = curl_proxy(url, file, args)
		if not return_code or return_code ~= 0 then
			return_code, result = curl_direct(url, file, args)
		end
		return return_code, result
	end
end

function url(...)
	local url = string.format("admin/services/%s", appname)
	local args = { ... }
	for i, v in pairs(args) do
		if v ~= "" then
			url = url .. "/" .. v
		end
	end
	return require "luci.dispatcher".build_url(url)
end

function trim(s)
	if type(s) ~= "string" then return "" end
	local i, j = 1, #s
	while i <= j and s:byte(i) <= 32 do i = i + 1 end
	while j >= i and s:byte(j) <= 32 do j = j - 1 end
	if i > j then return "" end
	return s:sub(i, j)
end

-- 分割字符串
function split(full, sep)
	if full then
		full = full:gsub("%z", "") -- 这里不是很清楚 有时候结尾带个\0
		local off, result = 1, {}
		while true do
			local nStart, nEnd = full:find(sep, off)
			if not nEnd then
				local res = string.sub(full, off, string.len(full))
				if #res > 0 then -- 过滤掉 \0
					table.insert(result, res)
				end
				break
			else
				table.insert(result, string.sub(full, off, nStart - 1))
				off = nEnd + 1
			end
		end
		return result
	end
	return {}
end

function is_exist(table, value)
	for index, k in ipairs(table) do
		if k == value then
			return true
		end
	end
	return false
end

function repeat_exist(table, value)
	local count = 0
	for index, k in ipairs(table) do
		if k:find("-") and k == value then
			count = count + 1
		end
	end
	if count > 1 then
		return true
	end
	return false
end

function remove(...)
	for i = 1, select("#", ...) do
		local value = select(i, ...)
		if type(value) == "string" and #value > 0 and value ~= "/" then
			sys.call(string.format("rm -rf -- %s", value))
		end
	end
end

function is_install(package)
	if package and #package > 0 then
		local file_path = "/usr/lib/opkg/info"
		local file_ext = ".control"
		local has = sys.call("[ -d " .. file_path .. " ]")
		if has ~= 0 then
			file_path = "/lib/apk/packages"
			file_ext = ".list"
		end
		return sys.call(string.format('[ -s "%s/%s%s" ]', file_path, package, file_ext)) == 0
	end
	return false
end

function get_args(arg)
	local var = {}
	for i, arg_k in pairs(arg) do
		if i > 0 then
			local v = arg[i + 1]
			if v then
				if repeat_exist(arg, v) == false then
					var[arg_k] = v
				end
			end
		end
	end
	return var
end

function get_function_args(arg)
	local var = nil
	if arg and #arg > 1 then
		local param = {}
		for i = 2, #arg do
			param[#param + 1] = arg[i]
		end
		var = get_args(param)
	end
	return var
end

function strToTable(str)
	if str == nil or type(str) ~= "string" then
		return {}
	end

	return loadstring("return " .. str)()
end

function is_json(str)
	if str and jsonc.parse(str) then
		return true
	end
	return false
end
datatypes.json = is_json

function is_timehhmm(str)
	local hour, minute = string.match(str, "^(%d?%d):(%d%d)$")
	if hour and minute then
		hour = tonumber(hour)
		minute = tonumber(minute)
		if hour >= 0 and hour <= 23 and minute >= 0 and minute <= 59 then
			return true
		end
	end
	return false
end
datatypes.timehhmm = is_timehhmm

function is_uuid(str)
	local pattern = "^%x%x%x%x%x%x%x%x%-%x%x%x%x%-%x%x%x%x%-%x%x%x%x%-%x%x%x%x%x%x%x%x%x%x%x%x$"
	return string.match(str, pattern) ~= nil
end
datatypes.uuid = is_uuid

function is_normal_node(e)
	if e and e.type and e.protocol and (e.protocol == "_balancing" or e.protocol == "_shunt" or e.protocol == "_iface" or e.protocol == "_urltest") then
		return false
	end
	return true
end

function is_special_node(e)
	return is_normal_node(e) == false
end

function is_ip(val)
	val = trim(val):lower()
	local str = val:match("%[(.-)%]") or val
	return datatypes.ipaddr(str) or false
end

function is_ipv6(val)
	val = trim(val):lower()
	local str = val:match("%[(.-)%]") or val
	return datatypes.ip6addr(str) or false
end

function is_local_ip(ip)
	ip = trim(ip):lower()
	ip = ip:gsub("^[%w%d]+://", "")   -- 去掉协议头
		:gsub("/.*$", "")          -- 去掉路径
		:gsub("^%[", ""):gsub("%]$", "") -- 去掉IPv6方括号
		:gsub(":%d+$", "")         -- 去掉端口
	return ip:match("^127%.") or ip:match("^10%.") or
		ip:match("^172%.1[6-9]%.") or ip:match("^172%.2[0-9]%.") or
		ip:match("^172%.3[0-1]%.") or ip:match("^192%.168%.") or
		ip == "::1" or ip:match("^f[cd]") or ip:match("^fe[89ab]")
end

function is_ipv6addrport(val)
	local address, port = val:match("%[(.-)%]:([0-9]+)$")
	if address and datatypes.ip6addr(address) and datatypes.port(port) then
		return true
	end
	return false
end

function get_ipv6_only(val)
	local result = ""
	local inner = val:match("%[(.-)%]") or val
	if datatypes.ip6addr(inner) then
		result = inner
	end
	return result
end

function get_ipv6_full(val)
	local result = ""
	if is_ipv6(val) then
		result = val
		if not val:match("%[.-%]") then
			result = "[" .. result .. "]"
		end
	end
	return result
end

function get_ip_type(val)
	if is_ipv6(val) then
		return "6"
	elseif datatypes.ip4addr(val) then
		return "4"
	end
	return ""
end

function is_mac(val)
	return datatypes.macaddr(val)
end

function ip_or_mac(val)
	if val then
		if get_ip_type(val) == "4" then
			return "ip"
		end
		if is_mac(val) then
			return "mac"
		end
	end
	return ""
end

function iprange(val)
	if val then
		local ipStart, ipEnd = val:match("^([^/]+)-([^/]+)$")
		if (ipStart and datatypes.ip4addr(ipStart)) and (ipEnd and datatypes.ip4addr(ipEnd)) then
			return true
		end
	end
	return false
end

function get_domain_from_url(url)
	local domain = string.match(url, "//([^/]+)")
	if domain then
		return domain
	end
	return url
end

function get_valid_nodes()
	local show_node_info = uci_get_c("@global_other[0]", "show_node_info") or "0"
	local nodes = {}
	local default_nodes = {}
	local other_nodes = {}
	uci_foreach_c("nodes", function(e)
		e.id = e[".name"]
		if e.type and e.remarks then
			local type_name = e.type
			if e.type == "sing-box" then type_name = "Sing-Box" end
			if e.protocol and (e.protocol == "_balancing" or e.protocol == "_shunt" or e.protocol == "_iface" or e.protocol == "_urltest") then
				e["remark"] = trim("%s：[%s]" % {type_name .. " " .. i18n.translatef(e.protocol), e.remarks})
				e["node_type"] = "special"
				if not e.group or e.group == "" then
					default_nodes[#default_nodes + 1] = e
				else
					other_nodes[#other_nodes + 1] = e
				end
			end
			local port = e.port or e.hysteria_hop or e.hysteria2_hop
			local is_realm = (e.type == "Hysteria2" or e.protocol == 'hysteria2') and e.hysteria2_realms or nil
			if (port and e.address) or is_realm then
				local address = e.address
				if is_ip(address) or datatypes.hostname(address) or is_realm then
					if (e.type == "sing-box" or e.type == "Xray") and e.protocol then
						local protocol = e.protocol
						if protocol == "vmess" then
							protocol = "VMess"
						elseif protocol == "vless" then
							protocol = "VLESS"
						elseif protocol == "shadowsocks" then
							protocol = "SS"
						elseif protocol == "shadowsocksr" then
							protocol = "SSR"
						elseif protocol == "wireguard" then
							protocol = "WG"
						elseif protocol == "hysteria" then
							protocol = "HY"
						elseif protocol == "hysteria2" then
							protocol = "HY2"
						elseif protocol == "anytls" then
							protocol = "AnyTLS"
						elseif protocol == "ssh" then
							protocol = "SSH"
						else
							protocol = protocol:gsub("^%l",string.upper)
						end
						type_name = type_name .. " " .. protocol
					end
					if is_ipv6(address) then address = get_ipv6_full(address) end
					type_name = is_realm and type_name .. " Realm" or type_name
					e["remark"] = trim("%s：[%s]" % {type_name, e.remarks})
					if show_node_info == "1" then
						port = (port or ""):gsub(":", "-")
						if not is_realm then
							e["remark"] = trim("%s：[%s] %s:%s" % {type_name, e.remarks, address, port})
						end
					end
					e.node_type = "normal"
					if not e.group or e.group == "" then
						default_nodes[#default_nodes + 1] = e
					else
						other_nodes[#other_nodes + 1] = e
					end
				end
			end
		end
	end)
	for i = 1, #default_nodes do nodes[#nodes + 1] = default_nodes[i] end
	for i = 1, #other_nodes do nodes[#nodes + 1] = other_nodes[i] end
	return nodes
end

function get_node_list()
	local node_list = {
		socks_list = {},
		normal_list = {},
	}
	uci_foreach_c("socks", function(s)
		if s.enabled == "1" and s.node then
			node_list.socks_list[#node_list.socks_list + 1] = {
				id = s[".name"],
				remark = i18n.translate("Socks Config") .. " [" .. s.port .. i18n.translate("Port") .. "]",
				group = "Socks"
			}
		end
	end)
	for k, e in ipairs(get_valid_nodes()) do
		if e.node_type == "normal" then
			node_list.normal_list[#node_list.normal_list + 1] = {
				id = e[".name"],
				remark = e["remark"],
				type = e["type"],
				chain_proxy = e["chain_proxy"],
				group = e["group"]
			}
		end
		if e.protocol and e.protocol:find("^_") then
			local proto = e.protocol:sub(2)
			if not node_list[proto .. "_list"] then
				node_list[proto .. "_list"] = {}
			end
			node_list[proto .. "_list"][#node_list[proto .. "_list"] + 1] = {
				id = e[".name"],
				remark = e["remark"],
				group = e["group"],
				o = e,
			}
		end
	end
	return node_list
end

function get_node_remarks(n)
	local remarks = ""
	if n then
		local type_name = n.type
		if n.type == "sing-box" then type_name = "Sing-Box" end
		if n.protocol and (n.protocol == "_balancing" or n.protocol == "_shunt" or n.protocol == "_iface" or n.protocol == "_urltest") then
			remarks = trim("%s：[%s]" % {type_name .. " " .. i18n.translatef(n.protocol), n.remarks})
		else
			if (n.type == "sing-box" or n.type == "Xray") and n.protocol then
				local protocol = n.protocol
				if protocol == "vmess" then
					protocol = "VMess"
				elseif protocol == "vless" then
					protocol = "VLESS"
				elseif protocol == "shadowsocks" then
					protocol = "SS"
				elseif protocol == "shadowsocksr" then
					protocol = "SSR"
				elseif protocol == "wireguard" then
					protocol = "WG"
				elseif protocol == "hysteria" then
					protocol = "HY"
				elseif protocol == "hysteria2" then
					protocol = "HY2"
				elseif protocol == "anytls" then
					protocol = "AnyTLS"
				elseif protocol == "ssh" then
					protocol = "SSH"
				else
					protocol = protocol:gsub("^%l",string.upper)
				end
				type_name = type_name .. " " .. protocol
			end
			if (n.type == "Hysteria2" or n.protocol == 'hysteria2') and n.hysteria2_realms then
				type_name = type_name .. " Realm"
			end
			remarks = trim("%s：[%s]" % {type_name, n.remarks})
		end
	end
	return remarks
end

function get_full_node_remarks(n)
	local remarks = get_node_remarks(n)
	if #remarks > 0 then
		local port = n.port or n.hysteria_hop or n.hysteria2_hop
		if n.address and port then
			port = port:gsub(":", "-")
			remarks = remarks .. " " .. n.address .. ":" .. port
		end
	end
	return remarks
end

function get_random_normal_node(exclude_id)
	local exclude_id_lookup = {}
	if type(exclude_id) == "table" then
		for i, v in ipairs(exclude_id) do
			exclude_id_lookup[v] = true
		end
	elseif type(exclude_id) == "string" then
		exclude_id_lookup[exclude_id] = true
	end
	local normal_list = {}
	for k, e in ipairs(get_valid_nodes()) do
		if e.node_type == "normal" and not exclude_id_lookup[e[".name"]] then
			normal_list[#normal_list + 1] = e
		end
	end
	if #normal_list > 0 then
		math.randomseed(os.time())
		local num = math.random(1, #normal_list)
		return normal_list[num]
	end
	return nil
end

function gen_uuid()
	local uuid = sys.exec("echo -n $(cat /proc/sys/kernel/random/uuid)")
	return uuid
end

function gen_random_char(length)
	if not length then length = 8 end
	return sys.exec("echo -n $(head /dev/urandom | tr -dc A-Za-z0-9 | head -c %s)" % length)
end

function chmod_755(file)
	if file and file ~= "" then
		if not fs.access(file, "rwx", "rx", "rx") then
			fs.chmod(file, 755)
		end
	end
end

function get_customed_path(e)
	return uci_get_c("@global_app[0]", e .. "_file")
end

function finded_com(e)
	local bin = get_app_path(e)
	if not bin then return end
	local s = luci.sys.exec('echo -n $(type -t -p "%s" | head -n1)' % { bin })
	if s == "" then
		s = nil
	end
	return s
end

function finded(e)
	return luci.sys.exec('echo -n $(type -t -p "/bin/%s" -p "/usr/bin/%s" "%s" | head -n1)' % {e, e, e})
end

function is_finded(e)
	return finded(e) ~= "" and true or false
end

function clone(org)
	local function copy(org, res)
		for k,v in pairs(org) do
			if type(v) ~= "table" then
				res[k] = v;
			else
				res[k] = {};
				copy(v, res[k])
			end
		end
	end

	local res = {}
	copy(org, res)
	return res
end

function get_bin_version_cache(file, cmd)
	sys.call("mkdir -p " .. CACHE_PATH)
	if fs.access(file) then
		chmod_755(file)
		local md5 = md5_file(file)
		if fs.access(CACHE_PATH .. "/" .. md5) then
			return sys.exec("echo -n $(cat %s)" % { CACHE_PATH .. "/" .. md5 })
		else
			local version = sys.exec(string.format("echo -n $(%s %s)", file, cmd))
			if version and version ~= "" then
				sys.call("echo '%s' > %s"  % { version, CACHE_PATH .. "/" .. md5})
				return version
			end
		end
	end
	return ""
end

function get_app_path(app_name)
	if com[app_name] then
		local def_path = com[app_name].default_path
		local path = uci_get_c("@global_app[0]", app_name:gsub("%-","_") .. "_file")
		path = path and (#path>0 and path or def_path) or def_path
		return path
	end
end

function get_app_version(app_name, file)
	if file == nil then file = get_app_path(app_name) end
	return get_bin_version_cache(file, com[app_name].cmd_version)
end

local function is_file(path)
	if path and #path > 1 then
		if sys.exec('[ -f "%s" ] && echo -n 1' % path) == "1" then
			return true
		end
	end
	return nil
end

local function is_dir(path)
	if path and #path > 1 then
		if sys.exec('[ -d "%s" ] && echo -n 1' % path) == "1" then
			return true
		end
	end
	return nil
end

local function get_final_dir(path)
	if is_dir(path) then
		return path
	else
		return get_final_dir(fs.dirname(path))
	end
end

local function get_free_space(dir)
	if dir == nil then dir = "/" end
	if sys.call("df -k " .. dir .. " >/dev/null 2>&1") == 0 then
		return tonumber(sys.exec("echo -n $(df -k " .. dir .. " | awk 'NR>1' | awk '{print $4}')"))
	end
	return 0
end

local function get_file_space(file)
	if file == nil then return 0 end
	if fs.access(file) then
		return tonumber(sys.exec("echo -n $(du -k " .. file .. " | awk '{print $1}')"))
	end
	return 0
end

function _unpack(t, i)
	i = i or 1
	if t[i] ~= nil then return t[i], _unpack(t, i + 1) end
end

function table_join(t, s)
	if not s then
		s = " "
	end
	local str = ""
	for index, value in ipairs(t) do
		str = str .. t[index] .. (index == #t and "" or s)
	end
	return str
end

local function exec(cmd, args, writer, timeout)
	local os = require "os"
	local nixio = require "nixio"

	local fdi, fdo = nixio.pipe()
	local pid = nixio.fork()

	if pid > 0 then
		fdo:close()

		if writer or timeout then
			local starttime = os.time()
			while true do
				if timeout and os.difftime(os.time(), starttime) >= timeout then
					nixio.kill(pid, nixio.const.SIGTERM)
					return 1
				end

				if writer then
					local buffer = fdi:read(2048)
					if buffer and #buffer > 0 then
						writer(buffer)
					end
				end

				local wpid, stat, code = nixio.waitpid(pid, "nohang")

				if wpid and stat == "exited" then return code end

				if not writer and timeout then nixio.nanosleep(1) end
			end
		else
			local wpid, stat, code = nixio.waitpid(pid)
			return wpid and stat == "exited" and code
		end
	elseif pid == 0 then
		nixio.dup(fdo, nixio.stdout)
		fdi:close()
		fdo:close()
		nixio.exece(cmd, args, nil)
		nixio.stdout:close()
		os.exit(1)
	end
end

function compare_versions(ver1, comp, ver2)
	local table = table

	if not ver1 then ver1 = "" end
	if not ver2 then ver2 = "" end

	local av1 = util.split(ver1, "[%.%-]", nil, true)
	local av2 = util.split(ver2, "[%.%-]", nil, true)

	local max = table.getn(av1)
	local n2 = table.getn(av2)
	if (max < n2) then max = n2 end

	local function version_part(value)
		local number = tonumber(value)
		if number then return number end
		local revision = type(value) == "string" and value:match("^[rR](%d+)$")
		return tonumber(revision) or 0
	end

	for i = 1, max, 1 do
		local s1 = version_part(av1[i] or 0)
		local s2 = version_part(av2[i] or 0)

		if comp == "~=" and (s1 ~= s2) then return true end
		if (comp == "<" or comp == "<=") and (s1 < s2) then return true end
		if (comp == ">" or comp == ">=") and (s1 > s2) then return true end
		if (s1 ~= s2) then return false end
	end

	return not (comp == "<" or comp == ">")
end

local function auto_get_arch()
	local arch = nixio.uname().machine or ""
	if not OPENWRT_ARCH and fs.access("/usr/lib/os-release") then
		OPENWRT_ARCH = sys.exec("echo -n $(grep 'OPENWRT_ARCH' /usr/lib/os-release | awk -F '[\\042\\047]' '{print $2}')")
		OPENWRT_BOARD = sys.exec("echo -n $(grep 'OPENWRT_BOARD' /usr/lib/os-release | awk -F '[\\042\\047]' '{print $2}')")
		if OPENWRT_ARCH == "" then OPENWRT_ARCH = nil end
		if OPENWRT_BOARD == "" then OPENWRT_BOARD = nil end
	end
	if not DISTRIB_ARCH and fs.access("/etc/openwrt_release") then
		DISTRIB_ARCH = sys.exec("echo -n $(grep 'DISTRIB_ARCH' /etc/openwrt_release | awk -F '[\\042\\047]' '{print $2}')")
		if DISTRIB_ARCH == "" then DISTRIB_ARCH = nil end
	end

	if arch:match("^i[%d]86$") then
		arch = "x86"
	elseif arch:match("armv5") then  -- armv5l
		arch = "armv5"
	elseif arch:match("armv6") then
		arch = "armv6"
	elseif arch:match("armv7") then  -- armv7l
		arch = "armv7"
	end

	if OPENWRT_ARCH or DISTRIB_ARCH then
		if arch == "mips" then
			if OPENWRT_ARCH and OPENWRT_ARCH:match("mipsel") == "mipsel"
			or DISTRIB_ARCH and DISTRIB_ARCH:match("mipsel") == "mipsel" then
				arch = "mipsel"
			end
		elseif arch == "armv7" then
			if OPENWRT_ARCH and not OPENWRT_ARCH:match("vfp") and not OPENWRT_ARCH:match("neon")
			or DISTRIB_ARCH and not DISTRIB_ARCH:match("vfp") and not DISTRIB_ARCH:match("neon") then
				arch = "armv5"
			end
		end
	end

	if arch == "aarch64" and OPENWRT_BOARD and OPENWRT_BOARD:match("rockchip") ~= nil then
		arch = "rockchip"
	end

	return trim(arch)
end

function parseURL(url_str)
	local res = {}

	-- 1. Get Scheme (http://)
	local rest = url_str
	local scheme, s_rest = url_str:match("^([%w%.%-%+]+)://(.+)$")
	if scheme then
		res.protocol = scheme
		rest = s_rest
	end

	-- 2. Get Authority (user:pass@host:port) and Path
	local authority, path = rest:match("^([^/]+)(.*)$")
	if path and path ~= "" then
		res.pathname = path:match("^([^?#]*)")
	end

	-- 3. Process Auth info (user:pass@)
	-- Use [^@]+ to match the content before the leftmost @.
	local user_info, host_port = authority:match("^([^@]+)@(.+)$")
	if user_info then
		local u, p = user_info:match("^([^:]+):?(.*)$")
		res.username = u or ""
		res.password = p or ""
	else
		host_port = authority
	end

	-- 4. Handles Host and Port (IPv6 compatible)
	-- First look for square brackets [], if not found, then look for regular colons.
	local ipv6_host, ipv6_port = host_port:match("^%[(.+)%]:(%d+)$")
	if ipv6_host then
		res.hostname = ipv6_host
		res.port = tonumber(ipv6_port)
	else
		-- Check if it's an IPv6 address with parentheses but no port number: [2001:db8::1]
		local pure_ipv6 = host_port:match("^%[(.+)%]$")
		if pure_ipv6 then
			res.hostname = pure_ipv6
		else
			-- IPv4 or hostname match
			local h, p = host_port:match("^([^:]+):(%d+)$")
			if h and p then
				res.hostname = h
				res.port = tonumber(p)
			else
				res.hostname = host_port
			end
		end
	end

	res.host = host_port
	return res
end

function parseDoH(doh_str)
	doh_str = trim(doh_str)
	if doh_str == "" then return nil end

	local url_part, ip_part
	if doh_str:find(",", 1, true) then
		url_part, ip_part = doh_str:match("^([^,]+),(.+)$")
	else
		url_part = doh_str
	end

	local res = parseURL(url_part)
	if not res then return nil end

	res.url = url_part
	if ip_part and ip_part ~= "" and is_ip(ip_part) then
		res.hostip = ip_part
	end

	return res
end

local default_file_tree = {
	x86_64  = "amd64",
	x86     = "386",
	aarch64 = "arm64",
	rockchip = "arm64",
	mips    = "mips",
	mips64  = "mips64",
	mipsel  = "mipsel",
	mips64el = "mips64el",
	armv5   = "arm.*5",
	armv6   = "arm.*6[^4]*",
	armv7   = "arm.*7",
	armv8   = "arm64",
	riscv64 = "riscv64"
}

local function get_api_json(url)
	local gh_proxy = uci_get_c("@global_app[0]", "gh_proxy_url") or ""
	local return_code, content
	if gh_proxy ~= "" then
		url = gh_proxy .. url
		return_code, content = curl_base(url, nil, curl_args)
	else
		return_code, content = curl_auto(url, nil, curl_args)
	end
	if return_code ~= 0 or content == "" then return {} end
	return jsonc.parse(content) or {}
end

local function check_path(app_name)
	local path = get_app_path(app_name) or ""
	if path == "" then
		return {
			code = 1,
			error = i18n.translatef("You did not fill in the %s path. Please save and apply then update manually.", app_name)
		}
	end
	return {
		code = 0,
		app_path = path
	}
end

function to_check(arch, app_name)
	local result = check_path(app_name)
	if result.code ~= 0 then
		return result
	end

	if not arch or arch == "" then arch = auto_get_arch() end

	local file_tree = com[app_name].file_tree[arch] or default_file_tree[arch] or ""

	if file_tree == "" then
		return {
			code = 1,
			error = i18n.translate("Can't determine ARCH, or ARCH not supported.")
		}
	end

	local local_version = get_app_version(app_name)
	local match_file_name = string.format(com[app_name].match_fmt_str, file_tree)
	local json = get_api_json(com[app_name]:get_url())

	if #json > 0 then
		json = json[1]
	end

	if json.tag_name == nil then
		return {
			code = 1,
			error = i18n.translate("Get remote version info failed.")
		}
	end

	local remote_version = json.tag_name
	if com[app_name].remote_version_str_replace then
		remote_version = remote_version:gsub(com[app_name].remote_version_str_replace, "")
	end
	local has_update = compare_versions(local_version:match("[^v]+"), "<", remote_version:match("[^v]+"))
--[[
	if not has_update then
		return {
			code = 0,
			local_version = local_version,
			remote_version = remote_version
		}
	end
]]--
	local asset = {}
	for _, v in ipairs(json.assets) do
		if v.name and v.name:match(match_file_name) then
			asset = v
			break
		end
	end
	if not asset.browser_download_url then
		return {
			code = 1,
			local_version = local_version,
			remote_version = remote_version,
			html_url = json.html_url,
			data = asset,
			error = i18n.translate("New version found, but failed to get new version download url.")
		}
	end

	return {
		code = 0,
		has_update = has_update,
		local_version = local_version,
		remote_version = remote_version,
		html_url = json.html_url,
		data = asset
	}
end

function to_download(app_name, url, size, task_id, keep_files)
	local result = app_name == appname and {code = 0} or check_path(app_name)
	if result.code ~= 0 then
		return result
	end

	if not url or url == "" then
		return {code = 1, error = i18n.translate("Download url is required.")}
	end

	if not keep_files then remove("/tmp/" .. app_name .. "_download.*") end

	local tmp_file
	if task_id and task_id:match("^[%w_-]+$") then
		tmp_file = "/tmp/" .. app_name .. "_download." .. task_id
		remove(tmp_file)
	else
		tmp_file = trim(util.exec("mktemp -u -t " .. app_name .. "_download.XXXXXX"))
	end

	if size then
		local kb1 = get_free_space("/tmp")
		if tonumber(size) > tonumber(kb1) then
			return {code = 1, error = i18n.translatef("%s not enough space.", "/tmp")}
		end
	end

	local _curl_args = clone(curl_args)
	table.insert(_curl_args, "--speed-limit 51200 --speed-time 15 --max-time 300")

	local gh_proxy = uci_get_c("@global_app[0]", "gh_proxy_url") or ""
	local return_code, result
	if gh_proxy ~= "" then
		url = gh_proxy .. url
		return_code, result = curl_base(url, tmp_file, _curl_args)
	else
		return_code, result = curl_auto(url, tmp_file, _curl_args)
	end
	result = return_code == 0

	if not result then
		exec("/bin/rm", {"-f", tmp_file})
		return {
			code = 1,
			error = i18n.translatef("File download failed or timed out: %s", url)
		}
	end

	return {code = 0, file = tmp_file, zip = com[app_name].zipped }
end

function to_download_progress(app_name, task_id, total_size)
	if not com[app_name] or type(task_id) ~= "string" or not task_id:match("^[%w_-]+$") then
		return {code = 1, error = i18n.translate("Invalid download task.")}
	end

	total_size = tonumber(total_size) or 0
	local tmp_file = "/tmp/" .. app_name .. "_download." .. task_id
	local downloaded = tonumber(fs.stat(tmp_file, "size")) or 0
	if app_name == appname then
		downloaded = (tonumber(fs.stat(tmp_file .. "1", "size")) or 0) + (tonumber(fs.stat(tmp_file .. "2", "size")) or 0)
	end
	local percent
	if total_size > 0 then
		-- The download request has not completed yet, so leave 100% for its success callback.
		percent = math.min(99, math.floor(downloaded * 100 / total_size))
	end

	return {code = 0, downloaded = downloaded, total = total_size, percent = percent}
end

function to_extract(app_name, file, subfix)
	local result = check_path(app_name)
	if result.code ~= 0 then
		return result
	end

	if not file or file == "" or not fs.access(file) then
		return {code = 1, error = i18n.translate("File path required.")}
	end

	local tools_name
	if com[app_name].zipped then
		if not com[app_name].zipped_suffix or com[app_name].zipped_suffix == "zip" then
			tools_name = "unzip"
		end
		if com[app_name].zipped_suffix and com[app_name].zipped_suffix == "tar.gz" then
			tools_name = "tar"
		end
		if tools_name then
			if sys.exec("echo -n $(command -v %s)" % { tools_name }) == "" then
				exec("/bin/rm", {"-f", file})
				return {
					code = 1,
					error = i18n.translatef("Not installed %s, Can't unzip!", tools_name)
				}
			end
		end
	end

	remove("/tmp/" .. app_name .. "_extract.*")

	local new_file_size = get_file_space(file)
	local tmp_free_size = get_free_space("/tmp")
	if tmp_free_size <= 0 or tmp_free_size <= new_file_size then
		return {code = 1, error = i18n.translatef("%s not enough space.", "/tmp")}
	end

	local tmp_dir = trim(util.exec("mktemp -d -t ".. app_name .."_extract.XXXXXX"))

	local output = {}

	if tools_name then
		if tools_name == "unzip" then
			local bin = sys.exec("echo -n $(command -v unzip)")
			exec(bin, {"-o", file, app_name, "-d", tmp_dir}, function(chunk) output[#output + 1] = chunk end)
		elseif tools_name == "tar" then
			local bin = sys.exec("echo -n $(command -v tar)")
			if com[app_name].zipped_suffix == "tar.gz" then
				exec(bin, {"-zxf", file, "-C", tmp_dir}, function(chunk) output[#output + 1] = chunk end)
				sys.call("/bin/mv -f " .. tmp_dir .. "/*/" .. com[app_name].name:lower() .. " " .. tmp_dir)
			end
		end
	end

	local files = util.split(table.concat(output))

	exec("/bin/rm", {"-f", file})

	return {code = 0, file = tmp_dir}
end

function to_move(app_name,file)
	local result = check_path(app_name)
	if result.code ~= 0 then
		return result
	end

	local app_path = result.app_path
	local bin_path = file
	local rm_tmp = "/tmp/" .. app_name .. "_download.*"
	if fs.stat(file, "type") == "dir" then
		bin_path = file .. "/" .. com[app_name].name:lower()
		rm_tmp = "/tmp/" .. app_name .. "_extract.*"
	end

	if not file or file == "" then
		remove(rm_tmp)
		return {code = 1, error = i18n.translate("Client file is required.")}
	end

	local new_version = get_app_version(app_name, bin_path)
	if new_version == "" then
		remove(rm_tmp)
		return {
			code = 1,
			error = i18n.translate("The client file is not suitable for current device.") .. app_name .. "__" .. bin_path
		}
	end

	local flag = sys.call('busybox pgrep -af "passwall/.*'.. app_name ..'" >/dev/null')
	if flag == 0 then
		sys.call("/etc/init.d/passwall stop")
	end

	local old_app_size = 0
	if fs.access(app_path) then
		old_app_size = get_file_space(app_path)
	end
	local new_app_size = get_file_space(bin_path)
	local final_dir = get_final_dir(app_path)
	local final_dir_free_size = get_free_space(final_dir)
	if final_dir_free_size > 0 then
		final_dir_free_size = final_dir_free_size + old_app_size
		if new_app_size > final_dir_free_size then
			remove(rm_tmp)
			return {code = 1, error = i18n.translatef("%s not enough space.", final_dir)}
		end
	end

	result = exec("/bin/mv", { "-f", bin_path, app_path }, nil, command_timeout) == 0

	remove(rm_tmp)
	if flag == 0 then
		sys.call("/etc/init.d/passwall restart >/dev/null 2>&1 &")
	end

	if not result or not fs.access(app_path) then
		return {
			code = 1,
			error = i18n.translatef("Can't move new file to path: %s", app_path)
		}
	end

	return {code = 0}
end

function get_version()
	local version
	local version_file = CACHE_PATH .. "/passwall_version"
	sys.call("mkdir -p " .. CACHE_PATH)
	if fs.access(version_file) then
		version = fs.readfile(version_file)
	else
		version = sys.exec("opkg list-installed luci-app-passwall 2>/dev/null | awk '{print $3}'")
		if not version or version == "" then
			version = sys.exec("apk list luci-app-passwall 2>/dev/null | awk '/installed/ {print $1}' | cut -d'-' -f4-")
		end
		version = (version or ""):match("^%s*(.-)%s*$")
		if version ~= "" then
			fs.writefile(version_file, version)
		end
	end
	version = (version or ""):match("^%s*(.-)%s*$")
	-- Normalize APK's -rN release notation while retaining the release number.
	return version:gsub("%-r(%d+)$", "-%1")
end

function to_check_self()
	local release = get_api_json(com[appname]:get_url())
	if type(release) == "table" and #release > 0 then
		release = release[1]
	end
	if type(release) ~= "table" or not release.tag_name then
		return {code = 1, error = i18n.translate("Get remote version info failed.")}
	end
	local local_version  = get_version()
	-- Keep the release suffix (-1, -2, ...) so package revisions are compared too.
	local remote_version = release.tag_name:gsub("^v", "")
	local has_update = compare_versions(local_version, "<", remote_version)
	local prefix, extension
	if sys.call("command -v apk >/dev/null 2>&1") == 0 then
		prefix, extension = "25.12+_", ".apk"
	else
		if sys.call("command -v uname >/dev/null 2>&1") ~= 0 then return {code = 1} end
		local kernel = trim(sys.exec("uname -r 2>/dev/null")):match("^(%d+%.%d+)")
		if not kernel then return {code = 1} end
		prefix = compare_versions(kernel, "<", "5.11") and "22.03-_" or "23.05-24.10_"
		extension = ".ipk"
	end
	local main, i18n_package
	for _, search_prefix in ipairs({prefix, ""}) do
		for _, asset in ipairs(release.assets or {}) do
			local name = asset.name or ""
			if name:find(search_prefix, 1, true) == 1 and name:sub(-#extension) == extension then
				name = name:sub(#search_prefix + 1)
				if not main and name:match("^luci%-app%-" .. appname .. "[_%-]%d") then main = asset end
				if not i18n_package and name:match("^luci%-i18n%-" .. appname .. "%-zh%-cn[_%-]%d") then i18n_package = asset end
			end
		end
		if main and i18n_package then break end
	end
	if not main or not i18n_package then
		return {code = 1, error = i18n.translate("Get remote version info failed.")}
	end
	return {
		code = 0, has_update = has_update, local_version = local_version,
		remote_version = remote_version, html_url = release.html_url,
		data = main, i18n = i18n_package
	}
end

function to_install_self(id, force)
	if not id or not id:match("^[%w_-]+$") then return {code = 1} end
	local dir = "/tmp/" .. appname .. "_luci_update." .. id
	local manager = sys.call("command -v apk >/dev/null 2>&1") == 0 and "apk" or "opkg"
	local extension = manager == "apk" and ".apk" or ".ipk"
	local status_dir = "/www/luci-static/resources/" .. appname .. "-update"
	local status = status_dir .. "/" .. id .. ".json"
	fs.mkdir(dir)
	fs.mkdir(status_dir)
	exec("/bin/mv", {"/tmp/" .. appname .. "_download." .. id .. "1", dir .. "/luci-app-" .. appname .. extension})
	exec("/bin/mv", {"/tmp/" .. appname .. "_download." .. id .. "2", dir .. "/luci-i18n-" .. appname .. "-zh-cn" .. extension})
	local script = dir .. "/luci_update.sh"
	if exec("/bin/cp", {"/usr/share/" .. appname .. "/luci_update.sh", script}) ~= 0 then
		remove(dir)
		return {code = 1}
	end
	fs.chmod(script, 755)
	fs.writefile(status, '{"installing":true}')
	sys.call("nohup " .. script .. " " .. dir .. " " .. status .. " " .. manager .. " " ..
		(force == "1" and "1" or "0") .. " >/dev/null 2>&1 </dev/null &")
	return {code = 0}
end

function is_js_luci()
	return sys.call('[ -f "/www/luci-static/resources/uci.js" ]') == 0
end

function set_default_cbi()
	local cbi = require "luci.cbi"
	if true then
		--Map
		local Map = cbi.Map
		local default_init = Map.__init__
		function Map.__init__(self, config, ...)
			if not config then config = c_config end
			default_init(self, config, ...)
			self.api = require "luci.passwall.api"
			if is_js_luci() == true then
				self.apply_on_parse = false
				self.is_js_luci = true
			end
		end
		function Map.foreach(self, stype, func)
			self.uci:foreach(self.config, stype, func)
		end
		function Map.template_path(self, template)
			return appname .. template
		end
		function Map.appendTemplate(self, template, data)
			local obj = cbi.Template(self:template_path(template))
			obj.map = self
			if data and next(data) then
				for k, v in pairs(data) do
					obj[k] = v
				end
			end
			self:append(obj)
			return obj
		end
	end
	if true then
		--AbstractSection
		local AbstractSection = cbi.AbstractSection
		function AbstractSection.appendTemplate(self, template, data)
			local obj = cbi.Template(self.map:template_path(template))
			obj.map = self.map
			obj.section = self
			if data and next(data) then
				for k, v in pairs(data) do
					obj[k] = v
				end
			end
			self:append(obj)
			return obj
		end
	end
	if true then
		--TextValue
		local TextValue = cbi.TextValue
		local default_init = TextValue.__init__
		function TextValue.__init__(self, ...)
			default_init(self, ...)
			self.template  = appname .. "/cbi/tvalue"
		end
	end
	if true then
		--DynamicList
		local DynamicList = cbi.DynamicList
		function DynamicList.write(self, section, value)
			local new_t = {}
			if type(value) == "table" then
				new_t = table_remove_duplicates(value)
			else
				new_t = { value }
			end
			local new_val
			if self.cast == "string" then
				new_val = table.concat(new_t, " ")
			else
				new_val = new_t
			end
			return cbi.AbstractValue.write(self, section, new_val)
		end
	end
	if true then
		--HideValue
		local HideValue = util.class(cbi.DummyValue)
		function HideValue.__init__(self, ...)
			cbi.DummyValue.__init__(self, ...)
			self.template = self.map:template_path("/cbi/hidevalue")
			self.value = "1"
		end
		cbi.HideValue = HideValue
	end
end

function set_type_cbi(s)
	local cbi = require "luci.cbi"
	local s1 = s.parent
	function s.option(s_self, class, option, ...)
		local obj  = class(s_self.map, s_self, option, ...)
		obj.config_option = option
		obj.option_prefix = s_self.option_prefix
		obj.option = s_self.option_prefix .. option
		obj.cfgvalue = function(self, section)
			local v
			if self.rewrite_option then
				v = self.map:get(section, self.rewrite_option)
			else
				v = self.map:get(section, self.config_option)
			end
			if util.instanceof(self, cbi.MultiValue) then
				if v and self.cast == "table" then
					return table.concat(v, " ")
				end
			end
			return v
		end
		obj.write = function(self, section, value)
			if s1.fields["type"]:formvalue(s_self.section) == s_self.type_name then
				local new_val = value
				if util.instanceof(self, cbi.DynamicList) then
					local new_t = {}
					if type(value) == "table" then
						new_t = table_remove_duplicates(value)
					else
						new_t = { value }
					end
					if self.cast == "string" then
						new_val = table.concat(new_t, " ")
					else
						new_val = new_t
					end
				end
				if util.instanceof(self, cbi.MultiValue) then
					local new_t = {}
					if type(value) == "table" then
						new_t = table_remove_duplicates(value)
					else
						string.gsub(value, '[^' .. " " .. ']+', function(v)
							new_t[#new_t + 1] = v
						end)
					end
					if self.cast == "string" then
						new_val = table.concat(new_t, " ")
					else
						new_val = new_t
					end
				end
				if self.rewrite_option then
					self.map:set(section, self.rewrite_option, new_val)
				else
					self.map:set(section, self.config_option, new_val)
				end
			end
		end
		obj.remove = function(self, section)
			if s1.fields["type"]:formvalue(s_self.section) == s_self.type_name then
				if self.rewrite_option then
					self.map:del(section, self.rewrite_option)
				else
					self.map:del(section, self.config_option)
				end
			end
		end
		obj.deplist2json = function(self, section, deplist)
			local deps, i, d = { }
			if type(self.deps) == "table" then
				if not next(self.deps) then
					self:depends({ type = s.type_name })
				end
				local list = deplist or self.deps
				for i, d in ipairs(list) do
					if s.type_name and not d["type"] then
						d["type"] = s.type_name
					end
					local a, k, v = { }
					for k, v in pairs(d) do
						if k:find("!", 1, true) then
							a[k] = v
						elseif k:find("^", 1, true) then
							a[k:sub(2)] = v
						elseif k:find(".", 1, true) then
							a['cbid%s' % k] = v
						elseif s_self.fields[k] then
							a['cbid.%s.%s.%s' %{ self.config, section, s_self.fields[k].option }] = v
						else
							a['cbid.%s.%s.%s' %{ self.config, section, k }] = v
						end
					end
					deps[#deps+1] = a
				end
			end
			return util.serialize_json(deps)
		end
		s_self:append(obj)
		s_self.fields[option] = obj
		return obj
	end
end

function type_cbi_section(s, s2)
	for i, v in ipairs(s2.children) do
		local o = s2.children[i]
		o.section = s
		s:append(o)
		s.fields[o.option] = o
	end
end

function return_map(map)
	local cbi = require "luci.cbi"
	if true then
		-- header
		local header = cbi.Template(appname .. "/cbi/header")
		header.map = map
		table.insert(map.children, 1, header)
	end
	if true then
		-- footer
		local footer = cbi.Template(appname .. "/cbi/footer")
		footer.map = map
		map:append(footer)
	end
	return map
end

function get_std_domain(domain)
	domain = trim(domain)
	if domain == "" then return "" end
	-- 含 # → ""
	for i = 1, #domain do
		if domain:byte(i) == 35 then return "" end -- '#'
	end
	local len = #domain
	local si, ei = 1, len
	-- 去前缀 '.'
	while si <= len and domain:byte(si) == 46 do si = si + 1 end
	-- 去后缀 '.'
	while ei >= si and domain:byte(ei) == 46 do ei = ei - 1 end
	if si > ei then return "" end
	domain = domain:sub(si, ei)
	len = #domain
	-- 是否有 '*'
	local star = false
	for i = 1, len do
		if domain:byte(i) == 42 then star = true break end
	end
	if not star then return domain end
	-- 切割 label
	local parts, pstart = {}, 1
	for i = 1, len + 1 do
		local b = (i <= len) and domain:byte(i) or 46 -- '.' 作为结束
		if b == 46 then
			parts[#parts + 1] = domain:sub(pstart, i - 1)
			pstart = i + 1
		end
	end
	-- 从右向左找含 '*' ,并删除包含 '*' 的部分及其左边部分
	for i = #parts, 1, -1 do
		local s = parts[i]
		local has = false
		for j = 1, #s do
			if s:byte(j) == 42 then has = true break end
		end
		if has then
			if i == #parts then return "" end
			local out = parts[i + 1]
			for k = i + 2, #parts do
				out = out .. "." .. parts[k]
			end
			return out
		end
	end
	return domain
end

function format_go_time(input, default)
	input = input and trim(input)
	local N = 0
	if input and input:match("^%d+$") then
		N = tonumber(input)
	elseif input and input ~= "" then
		for value, unit in input:gmatch("(%d+)%s*([hms])") do
			value = tonumber(value)
			if unit == "h" then
				N = N + value * 3600
			elseif unit == "m" then
				N = N + value * 60
			elseif unit == "s" then
				N = N + value
			end
		end
	end
	if N <= 0 then
		return default or "0s"
	end
	local result = ""
	local h = math.floor(N / 3600)
	local m = math.floor(N % 3600 / 60)
	local s = N % 60
	if h > 0 then result = result .. h .. "h" end
	if m > 0 then result = result .. m .. "m" end
	if s > 0 or result == "" then result = result .. s .. "s" end
	return result
end

function match_node_rule(name, rule)
	if not name then return false end
	if not rule or rule == "" then return true end
	-- split rule by || into OR groups
	local function split_or(expr)
		local t = {}
		for part in (expr .. "||"):gmatch("(.-)%|%|") do
			part = trim(part)
			if part ~= "" then
				table.insert(t, part)
			end
		end
		return t
	end
	-- split rule by &&
	local function split_and(expr)
		local t = {}
		for part in (expr .. "&&"):gmatch("(.-)%&%&") do
			part = trim(part)
			if part ~= "" then
				table.insert(t, part)
			end
		end
		return t
	end
	-- match single condition
	local function match_cond(str, cond)
		if cond == "" then
			return true
		end
		-- exclude: !xxx
		if cond:sub(1, 1) == "!" then
			local k = cond:sub(2)
			if k == "" then return true end
			return not str:find(k, 1, true)
		end
		-- prefix: ^xxx
		if cond:sub(1, 1) == "^" then
			local k = cond:sub(2)
			return str:sub(1, #k) == k
		end
		-- suffix: xxx$
		if cond:sub(-1) == "$" then
			local k = cond:sub(1, -2)
			return str:sub(-#k) == k
		end
		-- contains
		return str:find(cond, 1, true) ~= nil
	end
	-- check if all conditions in AND group match
	local function match_and_group(str, group_expr)
		for _, cond in ipairs(split_and(group_expr)) do
			if not match_cond(str, cond) then
				return false
			end
		end
		return true
	end
	-- OR logic: return true if any group matches
	for _, group in ipairs(split_or(rule)) do
		if match_and_group(name, group) then
			return true
		end
	end
	return false
end

local normal_nodes = {}
function get_batch_nodes(node)
	if #normal_nodes == 0 then
		for k, e in ipairs(get_valid_nodes()) do
			if e.node_type == "normal" and (not e.chain_proxy or e.chain_proxy == "") then
				normal_nodes[#normal_nodes + 1] = {
					id = e[".name"],
					remarks = e["remarks"],
					group = e["group"]
				}
			end
		end
	end
	if not node.node_group or node.node_group == "" then return {} end
	local nodes = {}
	for g in node.node_group:gmatch("%S+") do
		g = UrlDecode(g)
		for k, v in pairs(normal_nodes) do
			local gn = (v.group and v.group ~= "") and v.group or "default"
			if gn:lower() == g:lower() and match_node_rule(v.remarks, node.node_match_rule) then
				nodes[#nodes + 1] = v.id
			end
		end
	end
	return nodes
end

function get_socks_backup_nodes(id)
	id = trim(id)
	if id == "" then return "" end
	local socks = uci_get_c(id)
	local nodes
	if socks.backup_node_add_mode and socks.backup_node_add_mode == "batch" then
		local node = {}
		node.node_group = socks.backup_node_group
		node.node_match_rule = socks.backup_node_match_rule
		nodes = get_batch_nodes(node)
	else
		nodes = socks.autoswitch_backup_node
	end
	local backup_nodes, seen = {}, {}
	for _, v in ipairs(nodes or {}) do
		if v ~= socks.node and not seen[v] then
			seen[v] = true
			table.insert(backup_nodes, v)
		end
	end
	return table.concat(backup_nodes, " ")
end

function get_core(field, candidates)
	local v = uci_get_c("@global_subscribe[0]", field)
	if v and v ~= "" then
		for _, c in ipairs(candidates) do
			if c[2] == v and c[1] then
				return v
			end
		end
	end
	for _, c in ipairs(candidates) do
		if c[1] then return c[2] end
	end
	return nil
end

function cleanEmptyTables(t)
	if type(t) ~= "table" then return nil end
	for k, v in pairs(t) do
		if type(v) == "table" then
			t[k] = cleanEmptyTables(v)
		end
	end
	return next(t) and t or nil
end

function fetch_cert_sha256(host, port, sni, timeout, http3)
	if not host then return "" end
	port = tonumber(port) or 443
	sni = sni or host
	timeout = tonumber(timeout) or 5
	local cmd
	if http3 then
		cmd = string.format(
			"timeout %d curl --http3 -k -w '%%{certs}' -o /dev/null https://%s:%d 2>/dev/null " ..
			"| awk 'BEGIN{c=0}/BEGIN CERT/{c++} c==1{print} /END CERT/{if(c==1)exit}' " ..
			"| openssl x509 -outform der 2>/dev/null " ..
			"| sha256sum 2>/dev/null",
			timeout, host, port
		)
	else
		cmd = string.format(
			"timeout %d openssl s_client -connect %s:%d -servername %s -showcerts </dev/null 2>/dev/null " ..
			"| awk 'BEGIN{c=0}/BEGIN CERT/{c++} c==1{print} /END CERT/{if(c==1)exit}' " ..
			"| openssl x509 -outform der 2>/dev/null " ..
			"| sha256sum 2>/dev/null",
			timeout, host, port, sni
		)
	end
	local out = trim(sys.exec(cmd))
	local fp = out:match("^([0-9a-fA-F]+)")
	if not fp or fp:lower():match("^e3b0c44298fc1c149afbf4c8996fb924") then
		return ""
	end
	return fp:upper()
end

function sha256_xray_sb(str)
	local decoded = base64Decode(str)
	if decoded ~= str and #decoded == 32 then return str end
	local hex = str:gsub(":", "")
	if #hex ~= 64 or not hex:match("^[A-Fa-f0-9]+$") then return str end
	local binary = hex:gsub("%x%x", function(byte)
		return string.char(tonumber(byte, 16))
	end)
	return base64Encode(binary)
end

function sha256_sb_xray(str)
	local binary = base64Decode(str)
	if binary == str or #binary ~= 32 then return str end
	return (binary:gsub(".", function(byte)
		return string.format("%02X", string.byte(byte))
	end))
end

function vps_domain_exclude(domain)
	domain = trim(domain)
	if domain == "" then return true end
	local map = {
		["engage.cloudflareclient.com"] = 1, ["google.com"] = 1, ["youtube.com"] = 1,
		["github.com"] = 1, ["telegram.org"] = 1, ["cloudflare.com"] = 1,
		["bing.com"] = 1, ["x.com"] = 1, ["dns.google"] = 1, ["opendns.com"] = 1,
		["cloudflare-dns.com"] = 1, ["one.one.one.one"] = 1, ["quad9.net"] = 1,
		["adguard-dns.com"] = 1, ["nextdns.io"] = 1, ["libredns.gr"] = 1
	}
	while true do
		if map[domain] then return true end
		local p = domain:find("%.")
		if not p then break end
		domain = domain:sub(p + 1)
	end
	return false
end

function parse_realm_uri(uri)
	uri = trim(uri)
	if uri == "" then return nil end
	-- realm[+http]://token@server/realm_id?query
	local scheme = (uri:match("^realm%+http://") and "realm+http") or (uri:match("^realm://") and "realm")
	if not scheme then return nil end
	uri = uri:gsub("^realm%+http://", ""):gsub("^realm://", "")
	local token, server_url, realm_id, query = uri:match("^([^@]+)@([^/]+)/([^?]*)%??(.*)$")
	if not token or not server_url or not realm_id then return nil end
	realm_id = realm_id:gsub("/+$", "")
	local address, port = server_url:match("^%[([^%]]+)%]:(%d+)$") --ipv6:port
	if not address then
		address, port = server_url:match("^([^:]+):(%d+)$") --ipv4[domain]:port
	end
	address = address or server_url:match("^%[([^%]]+)%]$") or server_url
	port = tonumber(port) or (scheme == "realm+http" and 80 or 443)
	local realm = {
		scheme = scheme,
		token = token,
		server_url = server_url,
		address = address,
		port = port,
		realm_id = realm_id
	}
	-- 解析 query 中的 stun=
	local stun_servers
	for v in (query or ""):gmatch("[Ss][Tt][Uu][Nn]=([^&]+)") do
		stun_servers = stun_servers or {}
		stun_servers[#stun_servers + 1] = v
	end
	realm.stun_servers = stun_servers
	return realm
end

function get_network_devices()
	local _sysnet = "/sys/class/net/"
	-- Map UCI interface names to their device names and vice versa
	local _iface_to_dev = {}
	local _dev_to_ifaces = {}
	local _iface_proto = {}
	uci:foreach("network", "interface", function(sec)
		local name = sec[".name"]
		if name ~= "loopback" then
			_iface_proto[name] = sec.proto
			if sec.device then
				_iface_to_dev[name] = sec.device
				_dev_to_ifaces[sec.device] = _dev_to_ifaces[sec.device] or {}
				table.insert(_dev_to_ifaces[sec.device], name)
			end
		end
	end)
	-- Classify device type using sysfs attributes
	local function classify_sysfs(dev)
		if fs.stat(_sysnet .. dev .. "/bridge", "type") == "dir" then
			return i18n.translate("Bridge")
		elseif fs.stat(_sysnet .. dev .. "/wireless", "type") == "dir" then
			return i18n.translate("Wireless Adapter")
		elseif dev:match("^tun") or dev:match("^tap") or dev:match("^wg") or dev:match("^ppp") then
			return i18n.translate("Tunnel Interface")
		else
			return i18n.translate("Ethernet Adapter")
		end
	end
	-- Classify offline UCI interfaces by config hints
	local function classify_uci(dev_name, proto)
		if dev_name and dev_name:match("^br%-") then
			return i18n.translate("Bridge")
		elseif proto == "wireguard" or proto == "pppoe" or proto == "pptp" or proto == "l2tp" then
			return i18n.translate("Tunnel Interface")
		else
			return i18n.translate("Interface")
		end
	end

	local _seen = {}
	local _devices = {}
	-- Active kernel devices from /sys/class/net/
	-- Skip bridge member ports (/master) and DSA master devices (/dsa)
	local _iter = fs.dir(_sysnet)
	if _iter then
		for dev in _iter do
			if dev ~= "lo"
				and not dev:match("^veth")
				and not dev:match("^ifb")
				and not dev:match("^gre")
				and not dev:match("^sit")
				and not dev:match("^ip6tnl")
				and not dev:match("^erspan")
				and not fs.stat(_sysnet .. dev .. "/master", "type")
				and not fs.stat(_sysnet .. dev .. "/dsa", "type")
			then
				local dtype = classify_sysfs(dev)
				local label = dtype .. ': "' .. dev .. '"'
				if _dev_to_ifaces[dev] then
					label = label .. " (" .. table.concat(_dev_to_ifaces[dev], ", ") .. ")"
				end
				_devices[#_devices + 1] = { name = dev, label = label, sort = dtype .. ":" .. dev }
				_seen[dev] = true
			end
		end
	end
	-- UCI interfaces whose device does not currently exist
	for iface, dev in pairs(_iface_to_dev) do
		if not _seen[dev] then
			local dtype = classify_uci(dev, _iface_proto[iface])
			local label = dtype .. ': "' .. iface .. '"'
			_devices[#_devices + 1] = { name = iface, label = label, sort = "zzz:" .. iface }
			_seen[dev] = true
		end
	end
	table.sort(_devices, function(a, b) return a.sort < b.sort end)
	return _devices
end


function table_remove_duplicates(t)
	if not t or #t == 0 then return nil end
	local t_lookup = {}
	local new_t = {}
	local x
	for _, x in ipairs(t) do
		if x and #x > 0 then
			if not t_lookup[x] then
				t_lookup[x] = x
				new_t[#new_t+1] = x
			end
		end
	end
	return new_t
end

function gen_wireguard_key()
	if sys.call("command -v wg >/dev/null") == 0 then
		local private_key = sys.exec('echo -n $(wg genkey)')
		local public_key = sys.exec('echo -n $(echo "%s" | wg pubkey)' % private_key)
		return {
			private_key = private_key,
			public_key = public_key
		}
	end
	local xray = finded_com("xray")
	if xray then
		local result = sys.exec(xray .. " wg | awk -F ': ' '{print $2}'")
		local s = split(result, "\n")
		local private_key = s[1]
		local public_key = s[2]
		return {
			private_key = private_key,
			public_key = public_key
		}
	end
	local sb = finded_com("sing-box")
	if sb then
		local result = sys.exec(sb .. " generate wg-keypair | awk '{print $2}'")
		local s = split(result, "\n")
		local private_key = s[1]
		local public_key = s[2]
		return {
			private_key = private_key,
			public_key = public_key
		}
	end
end

function get_socks_port_by_cache(node_id)
	return get_cache_var("node_%s_socks_port" % { node_id })
end

function set_socks_port_to_cache(node_id, v)
	set_cache_var("node_%s_socks_port" % { node_id }, v)
end

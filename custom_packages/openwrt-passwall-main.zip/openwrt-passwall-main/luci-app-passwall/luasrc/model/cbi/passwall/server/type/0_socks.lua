if not api.is_finded("microsocks") then
	return
end

-- [[ microsocks ]]
local m, s1 = ...
local type_name = "Socks"

s1.fields["type"]:value(type_name, "Socks")
if not s1.fields["type"].default then
	s1.fields["type"].default = type_name
end

if s1.val["type"] and s1.val["type"] ~= type_name then
	return
end

local s = NamedSection(m, arg[1], "tmp_" .. s1.sectiontype)
s.parent = s1
s.type_name = type_name
s.option_prefix = "socks_"
api.set_type_cbi(s)

o = s:option(Value, "port", translate("Listen Port"))
o.datatype = "port"

o = s:option(Flag, "auth", translate("Auth"))

o = s:option(ListValue, "user", translate("User"))
for i, v in ipairs(user_list) do
	o:value(v[".name"], v.username)
end
o:depends({ auth = true })

o = s:option(Flag, "firewall_allow", translate("Firewall Allow"))
o.default = "0"

o = s:option(Value, "firewall_allow_src", translate("Source zone"))
o.rmempty = not m.is_js_luci
o.nocreate = true
o.allowany = true
o.default = "wan"
o.template = "cbi/firewall_zonelist"
o:depends({ firewall_allow = true })

o = s:option(Flag, "log", translate("Log"))
o.default = "1"

api.type_cbi_section(s1, s)
